<?php

namespace app\forms;


class SecurityAnswerForm
{
    public $email;
    public $password;
    public $password_repeat;
    public $security_answer;
}