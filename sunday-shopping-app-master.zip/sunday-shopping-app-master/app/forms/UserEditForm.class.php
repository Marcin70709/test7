<?php
/**
 * Created by PhpStorm.
 * User: TalarPC
 * Date: 16.05.2019
 * Time: 17:52
 */

namespace app\forms;

class UserEditForm
{
    public $id;
    public $login;
    public $password;
    public $security_question;
    public $security_answer;
    public $email;
    public $id_role;
    public $reputation;
    public $description;
}